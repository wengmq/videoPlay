#ifndef __QQSEND_THREAD_H_
#define __QQSEND_THREAD_H_

#include "PThreadCond.h"
#include "PThreadBase.h"
#include "TcpSocket.h"
#include "QQPacket.h"
#include "ShmFIFO.h"


//QQ�ذ����߳�
class CQQSendThread : public CThreadBase
{
public:

	CQQSendThread(CShmFIFO &fifo);
	~CQQSendThread();

	int run(void);
private:
	CShmFIFO &m_fifo;
	CQQPacket m_packet;
};


#endif /*  __QQSEND_THREAD_H_ */

